// ESM
export default {
  plugins: {
    '@tailwindcss/postcss': {},
    autoprefixer: {},
  },
}
// (o CommonJS con module.exports si no usas "type": "module")
